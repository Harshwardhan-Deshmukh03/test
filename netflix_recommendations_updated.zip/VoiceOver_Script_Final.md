# 🎤 VOICE-OVER SCRIPT — Decode the Tech · Episode 4
## "Netflix Recommendations" — Full 45-Minute Spoken Script

---

> ### HOW TO USE THIS SCRIPT
> - Every line is **exactly what you say out loud** — no guessing, no improvising needed
> - 🔴 **[CLICK]** = press the arrow key to advance the slide
> - ⏸️ **(pause 2 sec)** = stop talking, count two seconds silently, then continue
> - 👁️ **[LOOK UP]** = take your eyes off the screen, make eye contact with the room
> - 💡 **[POINT]** = gesture toward the highlighted element on screen
> - Italic text in parentheses = *stage directions, not spoken aloud*

---
---

# SLIDE 0 — THE INTRO SCREEN
## ⏱ Talk for: 45 seconds

Good evening, everyone, 

This is Ravi, and harsh is joining me today. We both are from ASDE team.

*(The D animation plays with the Tudum sound. Stand still. Say nothing for 3 full seconds after the sound finishes. Let the room absorb it. Then:)*

"That sound you just heard is one of the most recognised sounds in the world today.

That simple knock, now plays in 190 countries, every single day, hundreds of millions of times.

Welcome to Decode the Tech. Episode 5. 

Today we are going to take Netflix apart, layer by layer, and show you exactly how it knows what you want to watch — before you do."


*(pause 2 sec)*

🔴 **[CLICK]**

---
---

# SLIDE 1 — SIMPLE INTERFACE, HIDDEN SYSTEM
## ⏱ Talk for: 2 minutes

"Before we get into the detail, let's see the difficulty level of the
problem Netflix is solving.

This slide is called 'Simple Interface. Hidden System.' — and that's
exactly the theme for the whole talk.

Netflix had around 300 plus million paid memberships across
roughly 190 countries, with the product available in about 60 languages.
Annual revenue is around 45 billion dollars.

Now, the number that really matters for this session — 80 percent.

Over eighty percent of everything that members watch on Netflix — they found through a recommendation. Not by searching. Not because a friend told them. Not because of an advertisement.

A machine put it in front of them. And they watched it.

*(pause 2 sec)*

👁️ [LOOK UP] Think about the last five things you watched on Netflix.  How many of them did you actually go looking for? And how many just… appeared on your screen, and you clicked?

But none of those numbers work without the proper recommendation engine. Because Netflix's catalog has tens of thousands of titles. Without a recommendation system, a member opens the app, gets overwhelmed, finds nothing, and leaves.

Suppose If the recommendation
system underperforms, engagement drops, and that drops directly into
revenue. There's no fallback.

[SECTION B — WHAT IS ACTUALLY BEING PERSONALIZED]

"Now here's the part most people don't realize.

Netflix isn't just personalizing which titles you see. There are three
separate decisions happening for every single member, on every single
visit.

Netflix personalizes more than which titles you see — it personalizes which rows appear, how titles are ordered within each row, and which thumbnail represents the same show to different viewers. Three separate ranking decisions, assembled in under 200ms.

[PAUSE]

That's the problem statement: three separate personalization decisions,
at 300 million member scale, in the time it takes to blink."

🔴 **[CLICK]**

---
---

# SLIDE 2 — FROM DVD MAIL TO GLOBAL AI PLATFORM
## ⏱ Talk for: 3 minutes

"Let me take you back to where this started. Because Netflix did not begin as a technology company. It has started as a DVD rental service.

1997 It started as a DVD-rental service company.
Still... Every rental, every
star rating a user left — that was early signal. The mindset of
measuring taste started here, long before any machine learning.

💡 [POINT to 2007 on the timeline] **2007** — Netflix launches streaming. Suddenly they can see everything. Not just what you chose to rent — but what you paused. What you skipped after five minutes. What you re-watched three times. Everything they started capturing. 

**2009** —  Netflix posts a public challenge. Whoever can improve their recommendation accuracy by ten percent
They get One. Million. Dollars price money

Thousands of teams worldwide competed. 
—Ofcourse matrix factorization variants won the price


*2013 —  By analyzing viewer preferences and watching patterns, Netflix gained the confidence to invest in original content. Also They found that Recommendations were no longer just a feature— the started seeing this is as a product.

**2017** — they start personalising artwork. Which means...The same show starts showing different thumbnails to different people. We are going to see the example for this

**2020** — Introduced deep learning and shared embeddings. **2024** — a single Foundation Model. **2025** — FM-Intent, which is the most exciting development in this space right now.

The lesson from this timeline is simple. 
Not 1 or 2 years....This is 28 years of compounding. Every year, the system got smarter. Every year, the data got richer. 

🔴 **[CLICK]**

---
---

# SLIDE 3 — NETFLIX VS THE COMPETITION
## ⏱ Talk for: 2.5 minutes

"Now — before we go inside the algorithms, let me quickly address the question that I know is in the room.

👁️ [LOOK UP] What about Amazon Prime? What about JioHotstar? What about Disney Plus? Are they not doing the same thing?

Good question. And the honest answer is: all four of these platforms invest seriously in personalisation. I want to be clear about that upfront.

💡 [POINT to the bottom footnote] This 'Personalization Focus' score on screen — I need you to read that footnote. It says: this is an illustrative, qualitative rating for discussion, not an official benchmark. That is not me avoiding the question. That is me being accurate. There is no published head-to-head test of these systems.

What the score reflects is: how central is recommendation to each platform's core product, and how much do they publish about their research.

**Amazon Prime Video** — genuinely sophisticated. They personalise rows, thumbnails, and in 2024 they launched an LLM-based feature called AI Topics that groups content by semantic themes. They are serious about this. The difference is that for Amazon, video is one part of a much larger ecosystem. Their biggest data asset is your shopping behaviour — and shopping signals are not the same as viewing taste signals.

**JioHotstar** — they dominate the Indian market and do serious regional personalisation, especially for local language content. Their strength is also their difference: they are the home of live IPL cricket. And live sport is a completely different recommendation problem to on-demand video. When 50 million people all watch the same match at the same time, there is no personalisation happening at the content level.

**Disney Plus** — remarkable brand, unmatched IP: Marvel, Star Wars, Pixar. They personalise their experience. The difference is that when your catalog is mostly franchise content, the brand often does the recommendation work — you watch Avengers because you love Marvel, not because an algorithm nudged you.

**Netflix** is different because recommendation is not a feature they added to a business — it is the business. And because they share their research publicly, which is exactly why we are able to decode it today."

🔴 **[CLICK]**

---
---

# SLIDE 4 — THREE USERS, THREE HOMEPAGES
## ⏱ Talk for: 2 minutes

"Let me make all of this very concrete before we go technical.

Meet Arjun, Priya, and Rahul. Same Netflix subscription price. Same night. Same catalog of tens of thousands of titles. But watch what their homepages look like.

💡 [POINT to Arjun's card] Arjun is 35. He watches crime dramas. He binges three episodes a night at 11pm on his smart TV. He has given five stars to Mindhunter, True Detective, and Breaking Bad. His homepage shows: Ozark, The Wire, Narcos, Hannibal. And below that, a row that says 'Because you watched Mindhunter' — The Fall, You, Marcella.

💡 [POINT to Priya's card] Priya is 28. She watches one comedy episode before bed on her laptop. She has watched The Office three times. Her homepage shows: Schitt's Creek, Community, The Good Place, Superstore. Completely different from Arjun's screen.

💡 [POINT to Rahul's card] And Rahul watches full seasons of sci-fi on weekends on a 4K TV. He loved Dark, Stranger Things, The Expanse. His screen shows: Westworld, 1899, Dark Matter, Travelers.

*(pause 2 sec)*

👁️ [LOOK UP] These three people would not recognise each other's Netflix.

Same app. Same catalog. Zero overlap in what they see.

That is what we are going to explain for the next 30 minutes. How does one system produce three completely unique, personal experiences — for 301 million people — in under 200 milliseconds each?"

🔴 **[CLICK]**

---
---

# SLIDE 5 — OBJECTIVES AND TRADE-OFFS
## ⏱ Talk for: 2 minutes

"Before we get into HOW part, let's see.. what the system is actually trying to Optimize — and what are the challenges.

If u see left side of the screen .....
The system has three goals. 
First: **relevance** — 
Showing some recomandations is not the goal here..
What we are recommonding is very important and that should be very much relevent to the user behaviuor. 

Should show things which actually value, not just things that might get a quick click. 


Second: **discovery speed** — 
How fast the system is reacting....
When u login...if you cannot find something within about 90 seconds of opening the app, Netflix research shows that you are likely to close it. So the system has to work fast. 

Third: **long-term satisfaction** — not just 'will you watch the next episode', but 'will you still be subscribed in three months'.

Now lets see the challenges here
There are four genuinely hard problems here.

**Cold Start** — Imagine you join Netflix today. You have never watched anything. The system knows absolutely nothing about you Right..?. How does it recommend anything? 
It is like asking a stranger 'what should I eat for dinner?' — they have no idea what you like right.?. 
This is called the Cold Start problem. 

**the bubble problem.** — Let's say Arjun only watches crime dramas. The system keeps showing him crime dramas. He keeps watching them. 
 Over time, Arjun's Netflix becomes a very narrow world. He never discovers that he might actually love sci-fiction stories. 
 The system has to deliberately push something new at him, even when he didn't ask for it. 

**No Ground Truth** — Problem three — nobody tells the system if it was right.
Think about this. After you finish watching a show — do you go back to Netflix and say 'that was a great recommendation, well done'? No. Nobody does that. So how does the system know if it made a good call?
It has to guess. It looks at signals like... — did you finish the show? Did you watch the next episode immediately? Did you rewatch it a month later? But here is the problem. Finishing a show... does'nt mean you loved it. Sometimes you finish something just because you started it. so...The system is always working with incomplete information.

**Feedback Loops** — This is almost same as bubble problem
Here is a tricky one. The system learns from what people watch. But what people watch is partly influenced by what the system recommended. So the system is learning from its own past decisions.

Example: Netflix shows Arjun crime dramas → he watches them → system says "great, he loves crime dramas, show more" → he watches those too → system becomes 99% confident Arjun watches only crime dramas → never tries anything else.
The problem here is: the system is learning from its own decisions, not from Arjun's true taste.

So...Keep these four challenges in your mind.....
 Because understanding where these systems fail is as important as understanding how they work."

🔴 **[CLICK]**

---
---

# SLIDE 6 — WHAT GOES INTO THE SYSTEM: SIX SIGNALS
## ⏱ Talk for: 2 minutes

"Every time you open Netflix, the system is reading six different signals about you simultaneously.

💡 [POINT to each signal card as you name it]

**Interaction signals** — what you have watched, how much of it you finished, what you abandoned after three minutes, what you rewatched, what you searched for. These are the richest signals.

**Collaborative patterns** — The system compares you with members who behave similarly and uses those patterns to recommand some title to u

**Content metadata** — For event content uploads to the system...
It captures the attributes like: genre, cast, language, tone, pacing, release year, format.

**Request-time context** — what device are you on, what time is it, what have you done in this session so far. 
Watching Netflix on a phone at 7am is different from watching on a smart TV at 10pm.

**Session intent** — what are you clearly in the mood for right now? Lets say....If you have opened three sci-fi shows in the last 20 minutes and closed all of them quickly, that is a signal about next recomdandation.— 


**Negative signals** — What not to show also matters.. Right..? 
Yes..Skipping, dropping, or ignoring titles matters too. Also....Netflix states age and gender are not used as recommendation inputs.


🔴 **[CLICK]**

---
---

# SLIDE 7 — BEHIND THE SCENES: WHAT HAPPENS IN MILLISECONDS
## ⏱ Talk for: 2 minutes

"Let me walk you through what literally happens the moment you open the Netflix app. From your tap to your personalised homepage.

There are six stages.

💡 [POINT to Step 1] **Step 1 — You open the app.** Your device sends a request to Netflix's servers. Attached to that request: your member ID, your device type, the time, and what you did in your last session.

💡 [POINT to Step 2] **Step 2 — Your profile loads.** Your long-term preferences, your viewing history, your learned embeddings — all pulled from a fast cache. This is not computed on the fly. It was prepared in advance.

💡 [POINT to Step 3] **Step 3 — Retrieval.** The system cannot deeply score 15,000 titles in real time. So multiple retrieval models run in parallel — each one a different lens on the catalog — and together they narrow the field down to a few hundred strong candidates. We will talk about this in detail in a few minutes.

💡 [POINT to Step 4] **Step 4 — Ranking.** Now the heavy models score those few hundred candidates. Not just for clicks — for relevance, diversity, freshness, and long-term satisfaction together. This is where the five algorithms we are about to decode all play their part.

💡 [POINT to Step 5] **Step 5 — Artwork selection.** For every title that makes it onto your homepage, a separate model picks which thumbnail you see. This is a completely distinct decision from which title to show.

💡 [POINT to Step 6] **Step 6 — Your homepage renders.** Rows are assembled. Titles are ordered. Thumbnails are placed. Your unique screen appears.

*(pause 2 sec)*

💡 [POINT to the timing bar] All of this — every step — in under **200 milliseconds**. Less than the blink of an eye.

The key thing to understand about how this is possible: the heavy, expensive learning happens **offline**, in the background, continuously. The system trains, learns, and updates its models over hours and days. At request time — it just has to look things up and assemble them quickly.

Learn slowly. Serve in a blink. That is the architecture principle that makes this work."

🔴 **[CLICK]**

---
---

# SLIDE 8 — FIVE ALGORITHMS OVERVIEW
## ⏱ Talk for: 1.5 minutes

"Alright. This is what we came for.

The single most common misconception about Netflix is that there is one clever algorithm deciding what you watch. There is not.

There are **five** model families, each solving a different part of the problem, working together as a team. And for the next 20 minutes, I am going to take each one apart — with a worked example — so you can see exactly what each one does and why you need all five.

💡 [POINT to each algorithm card]

Number one: **Collaborative Filtering** — learns from people with similar taste.
Number two: **Matrix Factorization** — maps taste into a hidden mathematical space.
Number three: **Content-Based Filtering** — uses the show's own attributes.
Number four: **Deep Learning** — finds patterns no human explicitly programmed.
Number five: **Foundation Models and FM-Intent** — ties all four together with one shared understanding of you.

Let's go."

🔴 **[CLICK]**

---
---

# ⭐ THE ALGORITHM SECTION — 20 MINUTES TOTAL ⭐

---

# SLIDE 9 — ALGORITHM 1: COLLABORATIVE FILTERING
## ⏱ Talk for: 4 minutes

Collaborative Filtering.

"This is the oldest idea in the business.

The name sounds technical — Collaborative Filtering — but the concept is very simple.

👁️ [LOOK UP] Think about the last time a friend recommended something to you. A book, a restaurant, a show. Why did you trust them? Because you knew their taste was similar to yours. So when they say 'you have to watch this', you believe them.

Collaborative Filtering does exactly this — but instead of one friend, you have **millions of them**.
 
 the system figures out who has the most similar taste to yours — and quietly shows you what they loved."

*(pause)*
Lets get into the detail
---

💡 [POINT to the visualisation on screen]

Look at this. The white row is you. You have watched Breaking Bad, The Wire, and Mindhunter — all five stars. Now the system scans millions of members and finds people with the most similar patterns.

The green rows — 94% similar, 88% similar — these are your taste neighbours. And here is the key observation: **both of them watched Ozark**, and loved it. You have never seen Ozark. You never searched for it. You probably never heard of it.

But because two people who are 94% and 88% similar to you both gave it five stars — So directltly it will become ur Top Pick

*(pause 2 sec)*

👁️ [LOOK UP] You did not find Ozark. millions of strangers, without knowing it, effectively voted for it on your behalf.right.? 

This is the magic of collaborative filtering. It can find things you would never have found yourself, because it is not looking at the titles — it is looking at the patterns of human behavior.

Now — step by step, what happens technically:
One: every member is represented by their interaction history.
Two: the system finds members with the highest behavioral similarity to you.
Three: it looks at what those members rated highly that you have not seen.
Four: it ranks those titles by engagement strength.

Now lets talk about the Limitations of Collaborative Filtering

If you're brand new to Netflix, this algorithm produces **nothing**. You have no history, so you have no neighbours. That is called the **cold start problem**.

This is the reason we need the other four algorithms. Content-Based Filtering and The Foundation Model handles it. Each algorithm fills a gap the others leave open."

🔴 **[CLICK]**

---
---

# SLIDE 10 — ALGORITHM 2: MATRIX FACTORIZATION
## ⏱ Talk for: 4 minutes

Let me start with the problem it is solving.
👆 [POINT to the sparse matrix table]
Look at this table on screen. Rows are members — Arjun, Priya, Rahul, Kavya. Columns are shows — Breaking Bad, Ozark, The Office, Dark, Friends. Each cell should have a rating. But most cells are blank — shown as dashes.
Why? Because Arjun has only watched maybe 200 shows out of 15,000 on Netflix. So 99% of his row is empty. Same for everyone else.
How do you recommend anything when your data is 99% missing?
That is the problem Matrix Factorization solves.
(pause)
👆 [POINT to the taste-space map]
Now — forget the maths for a moment. Think of it like this.
Imagine you had to place every Netflix show on a map. Not a geographic map — a taste map. You have two directions on this map.
Left to right — how feel-good is the show? Left side is fun, light, easy to watch. Right side is heavy, intense, emotionally draining.
Bottom to top — how complicated is the story? Bottom is simple and easy to follow. Top is complex, layered, needs your full attention.
Now let's place some shows.
The Office — it is fun, it is light, the story is simple. So it goes bottom-left.
Breaking Bad — it is very heavy and intense, and the story is complex with many layers. So it goes top-right.
Friends — light and fun, even simpler than The Office. Bottom-left, close to The Office.
Dark — the German sci-fi. Very intense, very complex with timelines across three generations. Top-right, close to Breaking Bad.
(pause)
Now the important question — how did those shows end up in those positions? Who decided?
Nobody decided. No engineer sat down and said 'Breaking Bad is a 9 out of 10 on complexity.' The system figured it out on its own.
Here is how. The system looked at who watches Breaking Bad and who watches Dark. It found that the same group of people tend to watch both. And that same group does NOT watch The Office or Friends. So the system concluded — these two shows share something in common. It placed them close together on the map.
The labels 'dark' and 'complex' that we put on the axes? Those are just our human explanation after the fact. The system does not know those words. It just knows — these shows attract the same type of viewer, so they belong near each other.
(pause)
👆 [POINT to Arjun's blue square on the map]
Now Arjun gets placed on the same map based on what he has watched. He loved Breaking Bad and The Wire and Mindhunter — all intense, all complex. So he lands in the top-right corner. Right next to Breaking Bad and Dark.
👆 [POINT to the gold ✦ cells in the matrix table]
Dark is sitting right next to Arjun on the map. He has never watched it. But the system says — Arjun is in the same neighbourhood as Dark. So it predicts he would give Dark five stars. That is the gold cell you see in the table. That prediction becomes the recommendation.
👆 [POINT to Priya's blue square]
Now look at Priya. She loves The Office and Friends — both light and simple. She lands in the bottom-left corner. Far away from Dark and Breaking Bad. So the system predicts she would not enjoy those shows — and it never recommends them to her.
(pause)
👁️ [LOOK UP]
The map we are showing here has two directions — just to make it easy to visualise. Real Netflix does not use two. It uses hundreds of directions simultaneously. Some might capture tone. Some might capture pace. Some might capture how international a show feels. The system discovered all of them on its own just by watching which members watch which shows together.
And those position coordinates for every member and every title — those are called embeddings. Think of them as each person's and each show's address on the taste map. These addresses are then used by every other algorithm that comes after this. Algorithm three, four, and five all start from these addresses."

🔴 **[CLICK]**

---
---

# SLIDE 11 — ALGORITHM 3: CONTENT-BASED FILTERING
## ⏱ Talk for: 4 minutes

"Algorithm number three. Content-Based Filtering. And this one is refreshingly different from the previous two.

Collaborative filtering looks at people. Matrix factorization looks at patterns of behavior. Content-based filtering looks at **the show itself**.

The idea is this: if you loved a particular title, find other titles that are structurally similar — same genre, similar cast, same tone, same era, same pacing. Recommend those.

💡 [POINT to the visualisation on screen]

Here is the worked example. You watched Stranger Things and gave it five stars. The system looks at Stranger Things and builds an attribute profile: sci-fi genre, 1980s setting, mystery plot, ensemble cast, dark tone, supernatural themes.

Now it scans the entire catalog, scoring every title by how many of those attributes match. Dark — the German sci-fi series — matches on sci-fi, mystery, complex timeline, and dark tone: 92% similarity. The OA matches on mystery, supernatural, dark tone: 88%. 1899 matches on mystery, historical setting, dark tone, ensemble cast: 81%.

None of these require another user's data. The algorithm only needs the attributes of the title and your history.

*(pause 2 sec)*

Step by step:
One: build an attribute profile for every title on the platform.
Two: from your watch history, build a profile of what attributes you tend to love.
Three: score every unwatched title by how well its attributes match your profile.
Four: recommend the closest matches.

💡 [POINT to the 'powers' section] This powers the 'Because you watched' rows. And it has a superpower that collaborative filtering does not have: it works for **brand new titles with no watch history at all**. A show that premiered yesterday, with zero views from anyone, can still be recommended through content-based filtering — because it has attributes. The algorithm does not need any engagement data. That is a direct solution to the cold start problem for new content."

🔴 **[CLICK]**

---
---

# SLIDE 12 — ALGORITHM 4: DEEP LEARNING
## ⏱ Talk for: 4 minutes

"Algorithm number four. Deep Learning. And this is where it gets genuinely exciting.

The first three algorithms are powerful — but they mostly capture simple, linear relationships. If you liked X, you will probably like Y. If your taste-map position is here, you will like these titles over there.

Real human taste is not linear. It is complicated, contextual, and it shifts.

Deep learning — specifically neural networks and sequence models — can find patterns that are impossible to express as simple rules. Patterns that no human explicitly programmed.

💡 [POINT to the neural network diagram]

Look at this diagram. On the left: inputs. Your watch history, your ratings, your context — device, time of day, current session. These feed into layers of mathematical connections. Each hidden layer transforms the input in increasingly abstract ways, finding combinations of signals that the linear methods would never find.

And then there are **sequence models** — transformers — which do something even more powerful. They read your viewing history **in order**. Like reading a sentence and understanding it as a flow of meaning, not just a bag of words.

👁️ [LOOK UP] Here is a concrete example. Arjun's overall viewing history spans three years. Mostly crime dramas. But tonight — it is a Saturday — he has opened three sci-fi films in a row and watched the first twenty minutes of each. The sequence model reads that pattern and recognises: whatever Arjun's long-term taste is, **right now, tonight**, he is in a sci-fi mood. The next recommendation pivots accordingly.

This is the 'attention' mechanism you see in the diagram — the highlighted nodes. Attention weights recent, relevant actions more heavily than older ones. It literally pays more attention to what matters right now.

*(pause 2 sec)*

Step by step:
One: feed member and title embeddings from matrix factorization into the network.
Two: hidden layers find non-linear combinations of signals.
Three: sequence models encode viewing history as an ordered timeline.
Four: attention focuses on what is most recent and most relevant.
Five: output is a score predicting how much you will engage with a given title, right now.

The patterns this network discovers were not written by any engineer. They emerged from the data. That is what makes deep learning both powerful and, honestly, a little bit mysterious."

🔴 **[CLICK]**

---
---

# SLIDE 13 — ALGORITHM 5: FOUNDATION MODELS & FM-INTENT
## ⏱ Talk for: 4 minutes

"Algorithm number five. And this is the most recent, the most ambitious, and the one that brings everything else together.

Let me start with a problem. We have four algorithms. They are all doing their own thing. Collaborative filtering has its own representation of you. Matrix factorization has its own. The deep learning model has its own. Three different systems, three different views of the same person.

That is inefficient. And it creates inconsistencies.

**Foundation Model**. They trained one large model on everything. Every watch. Every search. Every rating. From all users. 
The output is one single, shared understanding of every member and every show.
Every part of Netflix — the homepage, search, ranking, even the emails they send you — all use this same shared understanding.
Think of it like this. Before this, every team in Netflix had their own version of who Arjun is. Now there is one official file — and everyone reads from the same file.

💡 [POINT to the architecture diagram]

But here is the really interesting part — and this was published on the Netflix Tech Blog in 2025. The problem with just knowing someone's long-term taste is that people's moods change.

Arjun loves crime dramas. That is his long-term taste. But tonight it is Friday, he has had a stressful week, and he wants something funny and light. His long-term taste says crime dramas. His tonight-intent says comedy.

**FM-Intent** — the 2025 extension — handles both at the same time.

💡 [POINT to the two branches on the diagram] It splits into two paths. The left path reads long-term taste — who you are based on months of history. The right path reads session intent — what you want right now, based on the last few minutes of behavior. Then it combines both into a single prediction: 'What should Arjun see tonight, given who he is and what mood he is in right now?'

*(pause 2 sec)*

👁️ [LOOK UP] And here is how this ties all five algorithms together. Collaborative filtering, matrix factorization, content-based filtering, and deep learning each still play their role. But the Foundation Model gives all of them a common, richer starting point — a shared understanding of every member and every title that is constantly being improved.

That layered orchestration — five models, one shared foundation — is the Netflix recommendation system.

Not one algorithm. A team. With a shared brain."

🔴 **[CLICK]**

---
---

# SLIDE 14 — RETRIEVAL
## ⏱ Talk for: 1.5 minutes

"So we have five algorithms. Now let's see how they actually work together when you open the app.
Think of it as a three-step funnel. Retrieval. Ranking. Then your homepage.
👆 [POINT to the retrieval rails on screen]
Step one is Retrieval. The job here is simple — cut the list down fast.
Netflix has 15,000 titles. It cannot deeply score all 15,000 for you in 200 milliseconds. So it runs four quick filters at the same time.
Collaborative Filtering asks — what did people like Arjun enjoy?
Content-Based asks — what is similar to what Arjun just watched?
Session asks — what matches his mood right now tonight?
Popularity asks — what is new or trending that Arjun hasn't seen?
Each filter throws out a small list. Put them all together and you go from 15,000 titles down to about 200 or 300 strong candidates.
That shortlist goes to the next step.
One thing to remember here — if a great title doesn't make it into these 200, it will never appear on your homepage. Retrieval is the gatekeeper."

🔴 **[CLICK]**

---

# SLIDE 15 — RANKING
## ⏱ Talk for: 1.5 minutes

"Stage two: **ranking**. Now we have a few hundred candidates. The heavier models score them.

And here is where it gets interesting. Netflix does not simply rank by 'probability of click'. That would be too naive. It optimises for multiple objectives at once.

A title that gets quick clicks but gets abandoned after ten minutes is not a good recommendation. A title that is watched, finished, and leads to a member coming back tomorrow — that is a good recommendation. The ranking system tries to predict long-term value, not just immediate engagement.

There is also deliberate **exploration**. Not every recommendation slot is filled with the highest-confidence prediction. Some slots are reserved for titles the system is less certain about — to learn more about your taste, and to stop you from getting trapped in a narrowing loop of the same type of content.

And then there is a page-level ranking decision on top of the row-level one: which rows appear on your screen, and in what order. That is a separate model, thinking about the layout of your homepage as a whole."

🔴 **[CLICK]**

---

# SLIDE 16 — THE LIVE HOMEPAGE
## ⏱ Talk for: 1.5 minutes

"Stage three: **assembly**. This is the homepage you actually see when you open Netflix.

💡 [POINT to the homepage mockup] Look at this screen. This is Arjun's view. At the top — the hero slot — the single most important recommendation, presented full-width. Below it, 'Top Picks for Arjun.' Below that, 'Because you watched Mindhunter.' Below that, 'Trending Now in India.' And 'New Releases.'

Every one of these rows was chosen specifically for Arjun. Their order was chosen. The titles within them were chosen and ordered. And every thumbnail on screen was chosen based on what Arjun's click history suggests he will respond to.

An important detail: the leftmost title in every row is the highest-confidence prediction. As you scroll right, confidence decreases. So if a member only looks at the first two titles in a row before scrolling down, Netflix needs its best bets to be there.

And much of this layout is quietly running as an A/B test right now. A small percentage of members are seeing a different row order, a different thumbnail, a different title in slot one. If that variant performs better on long-term engagement metrics, it becomes the new default for everyone."

🔴 **[CLICK]**

---

# SLIDE 17 — ARTWORK PERSONALIZATION
## ⏱ Talk for: 1.5 minutes

"And the layer that most people never know about: **artwork personalisation**.

💡 [POINT to the six thumbnails] These are six possible thumbnails for the same title. Same show. Six completely different images. Different mood, different focus, different visual style.

You see one of them. Your colleague opens Netflix and sees a different one. Not randomly — chosen specifically for each of you.

The system looks at your click history. Which thumbnails do you respond to? Images with lead actors prominently featured? Emotional confrontations? Dark, desaturated atmospheres? Action scenes? Over time, it learns your visual preferences just as it learns your content preferences.

*(pause 2 sec)*

👁️ [LOOK UP] Think about what this means. A correctly recommended title can still be skipped if the image representing it does not resonate with you. So the full recommendation chain is: which title to show you, where to place it on the page, and which image to use. Three separate decisions. All personalised. All running in under 200 milliseconds.

The artwork system uses contextual bandits — a type of reinforcement learning — to continuously test new thumbnail variants and update based on what works for different viewer profiles."

🔴 **[CLICK]**

---
---

# SLIDE 18 — WHAT'S NEXT FOR NETFLIX AI
## ⏱ Talk for: 1.5 minutes

"Where is all of this going?

**Conversational recommendations** — Netflix's 2025 research workshop included work on LLM-based discovery. The idea: you describe a mood in plain English — 'something dark but hopeful that I can finish tonight' — and the system understands what you mean and re-ranks accordingly. This is not in full production yet, but the research is active.

**FM-Intent expansion** — the foundation model published in 2025 is being integrated more deeply across homepage, search, and messaging. The goal is one unified understanding of you across every surface.

**Explainability** — research into telling you not just what to watch, but exactly why the system thinks you will love it. Deeper than 'because you watched X'.

**Debiasing** — correcting for the feedback loops and popularity biases that every recommendation system accumulates over time. If the system always promotes popular content, less popular content never gets a chance. Netflix is actively researching how to correct for this."

🔴 **[CLICK]**

---

# SLIDE 19 — TAKEAWAYS
## ⏱ Talk for: 1.5 minutes

"Let me close with five things to take out of this room.

💡 [POINT to each takeaway as you speak]

**One** — a simple interface hides a layered system. Three separate ranking decisions, assembled in under 200 milliseconds.

**Two** — there is no single Netflix algorithm. Five model families, working as a team, with a shared foundation.

**Three** — the system runs on behavior, not demographics. Age and gender are not used. What you do is everything.

**Four** — the pipeline is only as good as its handoffs. Retrieval sets a ceiling on ranking. Ranking sets a ceiling on what artwork can rescue.

**Five** — recommenders shape what you discover. Eighty percent of what you watch on Netflix, you never searched for. That influence comes with responsibility — balancing relevance with diversity, and engagement with long-term trust.

*(pause 2 sec)*

👁️ [LOOK UP] The next time you open Netflix and something catches your eye — something you did not know you wanted — now you know exactly how it got there."

🔴 **[CLICK]**

---
---

# SLIDE 20 — THE END SCREEN (UP NEXT)
## ⏱ Talk for: 30 seconds

*(Let the 'Up Next' screen sit for 2 seconds before speaking)*

"And just like Netflix after the finale — here is what comes next.

💡 [POINT to the '?' card] Episode 5 is a question mark. And that is deliberate.

👁️ [LOOK AT THE MANAGERS AND SENIOR STAKEHOLDERS DIRECTLY] Do you want us to Decode something next? What system would you like us to take apart?

The next episode is yours to choose.

Thank you for watching."

🔴 **[CLICK]**

---
---

# SLIDE 21 — LIVE QUIZ
## ⏱ Allow 4–5 minutes for interactive play

*(Project the QR code — make sure your Slido/Kahoot link is live before this slide)*

"Alright — one last thing. And this time, you play.

Scan that QR code with your phone. Pick a nickname. You will get five questions based on everything we covered today.

Fastest correct answers score highest. I am just the host — I am not playing.

Let us see who was paying attention."

*(Wait for most people to join — watch the join count on your host screen)*

"Okay — first question going up in three, two, one..."

*(Run the quiz. After all five questions, display the leaderboard.)*

"Third place — [name]. Second place — [name]. And first place — congratulations — [name].

Thank you all. That is Episode 4 of Decode the Tech."

---
---
---

# 📹 VIDEO RESOURCES FOR EACH ALGORITHM
## Watch before your session — Use as backup clips during Q&A

---

## 🔵 GENERAL / ALL ALGORITHMS OVERVIEW

| Video | Why watch it | Link |
|-------|-------------|------|
| **"How Recommender Systems Work — Netflix/Amazon"** · Art of the Problem | Best visual overview of collaborative filtering and content-based filtering for a non-technical audience. Animated. 10 minutes. Show this to your audience if you get a "can you show us a video" question. | https://www.youtube.com/watch?v=n3RKsY2H-NE |
| **"Netflix Research: Recommendations"** · Netflix YouTube | Official Netflix overview of how their recommendation system works. From the actual engineering team. 8 minutes. | https://www.youtube.com/watch?v=4aNfPe-pQqI |
| **"How Netflix Uses Recommender Systems"** · Sundog Education | Full case study breakdown with clear examples of how Netflix uses each algorithm type. | https://www.youtube.com/watch?v=r9vZzSka0mY |
| **"The Science Behind Netflix & Amazon Recommendations"** · ML Lecture | Comprehensive academic-style lecture covering all major recommendation techniques. 2024. | https://www.youtube.com/watch?v=4aYvrDufW64 |
| **"How Recommendation Algorithms Actually Work"** · YouTube 2026 | Updated explainer — most recent. Covers collaborative filtering, content-based, and deep learning. | https://www.youtube.com/watch?v=iWwQGYkZTAw |

---

## 🟥 ALGORITHM 1 — COLLABORATIVE FILTERING

| Video/Demo | Why watch it | Link |
|-------|-------------|------|
| **"Collaborative Filtering Explained"** · StatQuest with Josh Starmer | The gold standard explanation. Very clear, step by step, with great visuals. Watch this before your session. | https://www.youtube.com/watch?v=h9gpufJFF-0 |
| **Live Demo — MovieLens** | MovieLens is the standard public dataset Netflix researchers used for decades. Sign up, rate 20 movies, and watch the CF recommendations update in real time. This is the best live demo for a Q&A session. | https://movielens.org |
| **Google Developers — Recommendation Systems Crash Course** | Interactive exercises with collaborative filtering. The user-item matrix exercise is ideal for showing the audience. | https://developers.google.com/machine-learning/recommendation |

---

## 🟧 ALGORITHM 2 — MATRIX FACTORIZATION

| Video/Demo | Why watch it | Link |
|-------|-------------|------|
| **"Matrix Factorization for PCA, SVD — Recommendation System"** · YouTube | Clear visual walkthrough of how the user-item matrix gets factorised. Shows the latent factor space visually — exactly the taste-map we discuss. | https://www.youtube.com/watch?v=-XOj1sUemMM |
| **"Recommendation System — Matrix Factorization (SVD) Explained"** · Towards Data Science | Written article with excellent diagrams. Read the section on the 'decomposition example image' — it matches our slide perfectly. | https://towardsdatascience.com/recommendation-system-matrix-factorization-svd-explained-c9a50d93e488 |
| **Google ML Course — Matrix Factorization** | Interactive explanation from Google. The visual of U and V matrices decomposing R is the exact concept in our slide. | https://developers.google.com/machine-learning/recommendation/collaborative/matrix |

---

## 🟨 ALGORITHM 3 — CONTENT-BASED FILTERING

| Video/Demo | Why watch it | Link |
|-------|-------------|------|
| **"Content-Based Filtering Explained"** · Towards Data Science video | Clear visual comparison of content-based vs collaborative. Shows the attribute-matching approach step by step. | https://www.youtube.com/watch?v=2TRse41eAb8 |
| **Live Demo — Use Netflix itself** | The best live demo for content-based filtering is showing a Netflix 'Because you watched X' row live during the session. Open your own Netflix, find a show you recently watched, and the row below it is content-based filtering in production. |  *Open live Netflix during session* |
| **IMDb similarity feature** | IMDb's 'More like this' section uses content-based filtering on genres, directors, and cast. It is a clean, transparent real-world demo you can show in 60 seconds. | https://www.imdb.com |

---

## 🟦 ALGORITHM 4 — DEEP LEARNING (NCF + TRANSFORMERS)

| Video/Demo | Why watch it | Link |
|-------|-------------|------|
| **"Deep Learning for Recommender Systems: A Netflix Case Study"** · AAAI 2021 · Netflix Engineers | This is the actual Netflix research paper presented at a conference. Video of the talk by Netflix engineers Harald Steck and Justin Basilico. Directly relevant — this is the real system being described. | https://www.youtube.com/watch?v=O8Ayj3WAm2M |
| **"Deep Learning for Recommender Systems: A Netflix Case Study"** · 2023 version | Updated conference talk from Netflix. Covers neural collaborative filtering and transformer-based sequence models. | https://www.youtube.com/watch?v=8HIZkY6dWfQ |
| **"Neural Networks Explained Visually"** · 3Blue1Brown | If anyone in the room is unfamiliar with how neural networks work, this is the best visual explanation on the internet. Reference it during Q&A. | https://www.youtube.com/watch?v=aircAruvnKk |

---

## 🟩 ALGORITHM 5 — FOUNDATION MODELS & FM-INTENT

| Video/Demo | Why watch it | Link |
|-------|-------------|------|
| **Netflix Tech Blog — FM-Intent (May 2025)** | The actual published blog post by the Netflix engineers who built FM-Intent. Read this before your session. Contains the exact architecture diagram we use on slide 13. | https://netflixtechblog.com/fm-intent-predicting-user-session-intent-with-hierarchical-multi-task-learning-94c75e18f4b8 |
| **"Netflix's Recommendation Evolution"** · Ko-Jen (Mark) Hsiao · ACM RecSys 2023 | A Netflix engineer explains the evolution from early models to foundation models. Directly maps to our slide 13 content. | https://www.youtube.com/watch?v=i5yeODpCj7M |
| **"Integrating Netflix's Foundation Model into Personalization Applications"** · Netflix Tech Blog | Explains how the foundation model embeddings are used in practice — the infrastructure, the embedding store, and how it connects to production systems. | https://netflixtechblog.medium.com/integrating-netflixs-foundation-model-into-personalization-applications-cf176b5860eb |

---

## 🟪 BEST LIVE DEMOS TO SHOW YOUR AUDIENCE

These are the most impressive things you can show live, without any setup:

| Demo | What to do | Time needed |
|------|-----------|-------------|
| **Your own Netflix homepage** | Open Netflix live. Show your personal homepage. Then switch to a colleague's profile on the same account. The instant visual contrast — completely different rows — is the most powerful demonstration of personalisation in the entire session. | 2 minutes |
| **The 'Because you watched' row** | Open any show you recently finished. Scroll down. Show the 'Because you watched' row with content-based recommendations right there in production. | 1 minute |
| **Two browser windows — same Netflix** | If you can get a colleague to open Netflix on their phone simultaneously, put your homepages side by side. The visual impact of how different they are is better than any slide. | 2 minutes |
| **MovieLens live** | Go to movielens.org, rate 10 movies quickly, and watch personalised collaborative filtering recommendations appear. Free, instant, no account needed for basic use. | 3 minutes |

---

## 📋 PRESENTER CHECKLIST (the night before)

- [ ] Download and place `tudum.mp3` next to the HTML file
- [ ] Test the D animation and sound in your actual browser
- [ ] Set up your quiz on Slido / Kahoot and paste the QR into slide 21
- [ ] Have Netflix open in a separate browser tab — ready for the live homepage demo
- [ ] Read the FM-Intent blog post once — it is a 7-minute read and will make slide 13 feel very natural
- [ ] Do one full run-through of this script at home, out loud, timed. Target: 42–44 minutes.

